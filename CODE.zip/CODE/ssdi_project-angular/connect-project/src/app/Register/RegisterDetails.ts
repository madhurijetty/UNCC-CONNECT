export class RegisterDetails {

  student_id: number;
  first_name: string;
  middle_name: string;
  last_name: string;
  personal_email_id: string;
  contact_number: number;
  password: string;
  linked_in_id: string;
  graduation_year: number;
  major: string;
  student_type: string;
  profileImage : string;
  constructor() {

  }
}
