export class Message {
  message: string;

  attachment: string;

  firstName: string;

  middleName: string;

  lastName: string;

  gradationYear: number;
  linkedInId: string;

  major: string;

  fromStudentId: number;

  profilePic: string;

  messageId : number;

}
